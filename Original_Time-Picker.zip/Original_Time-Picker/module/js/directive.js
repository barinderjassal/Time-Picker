/**
 * Created by Barinderjit Singh on 20/10/16.
 * Description:
 *
 */

define([
    'angular',
    'moment',
    'text!module/template/template.html',
    'module/js/controller',
    'module/js/timepicker'
], function (angular, moment, template) {
    angular.module('TimePicker').directive('timecatcher', [function () {
        return {
            restrict: 'EA',
            template: template,
            scope: {
               timePickerConfig: '='
            },
            controller: 'TimePickerController',
            link: function (scope, element, attrs) {
                
            }
        };

    }])
    .directive("regExpRequire", function() {
        var regexp;
        return {
            restrict: "A",
            link: function(scope, elem, attrs) {
               regexp = eval(attrs.regExpRequire);
                console.log('in directive::' + regexp);
                var char;
                elem.on("keypress", function(event) {
                    char = String.fromCharCode(event.which)
                    parseInt(char);
                    if(!regexp.test(elem.val() + char))
                        event.preventDefault();
                })
            }
        }

    });
});
