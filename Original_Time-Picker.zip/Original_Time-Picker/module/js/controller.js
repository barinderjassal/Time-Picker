/**
 *
 * Created by Barinderjit Singh on 20/10/16.
 *
 */

define([
    'angular',
    'moment',
    'module/js/timepicker'
], function (angular) {
    angular.module('TimePicker').controller('TimePickerController', ['$scope', function ($scope) {
        
        $scope.hourStep = 1;
        $scope.minuteStep = 1;
        $scope.parseInt = parseInt;
        
        var hour,
            minute,
            formattingHours = function (hr) {
                return hr < 10 ? '0' + hr : hr;
            },
            formattingMinutes = function (min) {
                return min < 10 ? '0' + min : min;
            },
            initialize = function (config) {
                if (config !== undefined && config !== null && (typeof config === 'object')) {
                    $scope.options = {
                        hrStep: config.hoursStep,
                        minStep: config.minutesStep,
                        myTime: config.currentDate,
                        hours: config.currentDate.getHours(),
                        minutes: config.currentDate.getMinutes(),
                        meridian: config.isMeridian,
                        displayMeridian: true, // 'AM'
                        invalidHours: '',
                        invalidMinutes: '',
                        showAmPmButton: true,
                        toggleMeridian: function () {
                            //([01]?[0-9]|2[0-3]):[0-5][0-9]
                            //$scope.regExForHour="([01]?[0-9]|1[0-2])";                        
                            if (!!$scope.options.showAmPmButton) {
                                $scope.options.showAmPmButton = false; // going in 24H format
                                $scope.options.meridian = !$scope.options.meridian;
                                if ($scope.options.hours === 12 && $scope.format === 'PM') {
                                    $scope.options.hours = 23;
                                } else if ($scope.options.hours === 12 && $scope.format === 'AM') {
                                    $scope.options.hours = 12;
                                } else if ($scope.options.hours < 12 && $scope.format === 'PM') {
                                    $scope.options.hours += 12;
                                } else if ($scope.options.hours < 12 && $scope.format === 'AM') {
                                    $scope.options.hours = $scope.options.hours;
                                }
                            } else {
                                $scope.options.showAmPmButton = true;
                                $scope.options.meridian = !$scope.options.meridian;
                                if ($scope.options.hours === 23) {
                                    $scope.options.hours = 12;
                                    $scope.format = 'PM';
                                } else if ($scope.options.hours === 12) {
                                    $scope.options.hours = 12;
                                    $scope.format = 'PM';
                                } else if ($scope.options.hours < 12) {
                                    $scope.options.hours = $scope.options.hours;
                                    $scope.format = 'AM';
                                } else if ($scope.options.hours > 12 && $scope.options.hours < 23) {
                                    $scope.options.hours -= 12;
                                    $scope.format = 'PM';
                                }
                            }
                            $scope.stringHours = formattingHours($scope.options.hours);
                        },
                        updateHours: function (event) {
                            if (!!$scope.options.showAmPmButton) {
                                if ($scope.stringHours === 'undefined' || $scope.stringHours === '') {
                                    //checking first digit, must be 0-1
                                    if (event.which !== 48 && event.which !== 49) {
                                        event.preventDefault();
                                    }
                                } else if ($scope.stringHours.length) {
                                    if ($scope.stringHours === '0') {
                                        // if first is 0, then next would be 1-9
                                        if (event.which <= 48 || event.which > 57) {
                                            event.preventDefault();
                                        }
                                    } else if ($scope.stringHours === '1') {
                                        // if first is 1, then next would be 0-2
                                        if (event.which < 48 || event.which > 50) {
                                            event.preventDefault();
                                        }
                                    }
                                }
                            } else {
                                // in 24 H format
                                if ($scope.stringHours === 'undefined' || $scope.stringHours === '') {
                                    if (event.which !== 48 && event.which !== 49 && event.which !== 50) {
                                        event.preventDefault();
                                    }
                                } else if ($scope.stringHours.length) {
                                    if ($scope.stringHours === '0') {
                                        if (event.which < 48 || event.which > 57) {
                                            event.preventDefault();
                                        }
                                    } else if ($scope.stringHours === '1') {
                                        if (event.which < 48 || event.which > 57) {
                                            event.preventDefault();
                                        }
                                    } else if ($scope.stringHours === '2') {
                                        if (event.which < 48 || event.which > 51) {
                                            event.preventDefault();
                                        }
                                    }
                                }
                            }
                        },
                        updateMinutes: function (event) {
                            if ($scope.stringMinutes === 'undefined' || $scope.stringMinutes === '') {
                                if (!(event.which >= 48 && event.which <= 53)) {
                                    event.preventDefault();
                                }
                            } else if ($scope.stringMinutes.length) {
                                if ($scope.stringMinutes === '0' || $scope.stringMinutes === '1' || $scope.stringMinutes === '2' || $scope.stringMinutes === '3' || $scope.stringMinutes === '4' || $scope.stringMinutes === '5') {
                                    // if first is 0-5, then next digit would be 0-9, <48 && >57
                                    if (event.which < 48 || event.which > 57) {
                                        event.preventDefault();
                                    }
                                }
                            }
                        },
                        update: function () {
                            var dt = config.currentDate;
                            $scope.options.hours = config.setHour;
                            $scope.options.minutes = config.setMin;
                            $scope.stringHours = formattingHours($scope.options.hours);
                            $scope.stringMinutes = formattingMinutes($scope.options.minutes);
                            dt.setHours($scope.stringHours, $scope.stringMinutes);
                            $scope.options.myTime = dt;
                        },
                        clear: function (getHour, getMinute) {
                            hour = Number(getHour); // converting string hours to number
                            minute = Number(getMinute); // converting string minutes to number

                            $scope.options.myTime = null;
                            $scope.stringHours = null;
                            $scope.stringMinutes = null;
                            $scope.clearTime = true;
                            $scope.options.showAmPmButton = false;
                        },
                        incrementHours: function () {
                            if ($scope.stringHours == null) {
                                $scope.stringHours = hour;
                                $scope.options.showAmPmButton = true;
                                $scope.clearTime = false;
                            }
                            // first check format
                            $scope.options.hours = Number($scope.stringHours);

                            if ($scope.options.meridian === true) {
                                var newHourVal = $scope.options.hours + $scope.hourStep;
                                if (newHourVal < 12) {
                                    $scope.options.hours = newHourVal;
                                } else if ($scope.options.hours < 12 && newHourVal === 12) {
                                    $scope.format === 'AM' ? $scope.format = 'PM' : $scope.format = 'AM';
                                    $scope.options.hours += $scope.hourStep;
                                } else if ($scope.options.hours === 12 && newHourVal > 12) {
                                    $scope.options.hours = $scope.hourStep;
                                } else if (newHourVal > 12) {
                                    $scope.format === 'AM' ? $scope.format = 'PM' : $scope.format = 'AM';
                                    $scope.options.hours = newHourVal - 12;
                                }
                            } else {
                                //if meridian is false, 24 hour format, hour between 0-23
                                $scope.options.hours += $scope.hourStep;
                                if ($scope.options.hours === 24) {
                                    $scope.options.hours = 0;
                                } else if ($scope.options.hours > 24) {
                                    $scope.options.hours -= 24;
                                }
                            }
                            $scope.stringHours = formattingHours($scope.options.hours);
                        },
                        decrementHours: function () {
                            if ($scope.stringHours == null) {
                                $scope.options.hours = hour;
                                $scope.options.showAmPmButton = true;
                                $scope.clearTime = false;
                            }

                            $scope.options.hours = Number($scope.stringHours);

                            var newHourVal = $scope.options.hours - $scope.hourStep;
                            if ($scope.options.meridian === true) {
                                if (newHourVal > 0 && $scope.options.hours === 12) {
                                    $scope.options.hours = newHourVal;
                                    $scope.format === 'AM' ? $scope.format = 'PM' : $scope.format = 'AM';
                                } else if ($scope.options.hours > 0 && newHourVal === 0) {
                                    //$scope.format == 'AM' ? $scope.format = 'PM' : $scope.format = 'AM'; 
                                    $scope.options.hours = 12;
                                } else if ($scope.options.hours > 0 && newHourVal < 0) {
                                    $scope.format === 'AM' ? $scope.format = 'PM' : $scope.format = 'AM';
                                    $scope.options.hours = newHourVal + 12;
                                } else if (newHourVal > 0 && $scope.options.hours === 12) {
                                    $scope.format === 'AM' ? $scope.format = 'PM' : $scope.format = 'AM';
                                    $scope.options.hours = newHourVal;
                                } else if (newHourVal > 0) {
                                    $scope.options.hours = newHourVal;
                                }
                            } else {
                                $scope.options.hours -= $scope.hourStep;
                                if ($scope.options.hours === -1) {
                                    $scope.options.hours = 23;
                                }
                                if ($scope.options.hours < 0) {
                                    $scope.options.hours += 24;
                                }
                            }
                            $scope.stringHours = formattingHours($scope.options.hours);
                        },
                        incrementMinutes: function () {
                            if ($scope.stringMinutes == null) {
                                $scope.options.minutes = minute;
                                $scope.options.showAmPmButton = true;
                                $scope.clearTime = false;
                            }

                            $scope.options.minutes = Number($scope.stringMinutes);

                            var newMinuteValue = $scope.options.minutes + $scope.minuteStep; // incremented value
                            if ($scope.options.meridian === true) {
                                // if meridian is true, 12H format, hours between 1-12
                                if (newMinuteValue < 60) {
                                    $scope.options.minutes = newMinuteValue;
                                } else if ($scope.options.minutes < 60 && newMinuteValue === 60) {
                                    $scope.options.hours += 1;
                                    if ($scope.options.hours === 12) {
                                        $scope.format === 'AM' ? $scope.format = 'PM' : $scope.format = 'AM';
                                    }
                                    $scope.options.minutes = 0;
                                } 
								else if (newMinuteValue >= 60 && $scope.options.hours === 11) {
                                    $scope.options.hours += 1;
                                    
                                    $scope.format === 'AM' ? $scope.format = 'PM' : $scope.format = 'AM';
                                    $scope.options.minutes = newMinuteValue - 60;
                                }else if (newMinuteValue >= 60) {
                                    $scope.options.hours += 1;
                                    if ($scope.options.hours > 12) {
                                        $scope.format === 'AM' ? $scope.format = 'PM' : $scope.format = 'AM';
										$scope.options.hours = 1;
                                    }
                                    $scope.options.minutes = newMinuteValue - 60;
                                } /*
else if ($scope.options.hours === 12 && newMinuteValue >= 60) {
                                    $scope.options.hours = 0;
                                    $scope.options.minutes = newMinuteValue - 60;
                                } */

                            } else {
                                // if meridian is false, 24H format, hours between 0-23
                                if (newMinuteValue === 60 && $scope.options.hours === 23) {
                                    $scope.options.minutes = 0;
                                    $scope.options.hours = 0;
                                } else if (newMinuteValue === 60 && $scope.options.hours < 23) {
                                    $scope.options.minutes = 0;
                                    $scope.options.hours += 1;
                                } else if (newMinuteValue > 60 && $scope.options.hours < 23) {
                                    $scope.options.minutes = newMinuteValue - 60;
                                    $scope.options.hours += 1;
                                } else if (newMinuteValue < 60 && $scope.options.hours <= 23) {
                                    $scope.options.minutes = newMinuteValue;
								} else if (newMinuteValue > 60 && $scope.options.hours === 23) {
                                    $scope.options.hours = 0;
                                    $scope.options.minutes = newMinuteValue - 60;
                                    
                                }
                            }
							$scope.stringHours = formattingHours($scope.options.hours);
                            $scope.stringMinutes = formattingMinutes($scope.options.minutes);
                        },
                        decrementMinutes: function () {
                            if ($scope.stringMinutes == null) {
                                $scope.options.minutes = minute;
                                $scope.options.showAmPmButton = true;
                                $scope.clearTime = false;
                            }
                            var newMinutesValue = $scope.options.minutes - $scope.minuteStep;

                            if ($scope.options.meridian === true) {
                                // meridian is true, 12H format, hours between 1-12
                                if (newMinutesValue > 0) {
                                    $scope.options.minutes = newMinutesValue;
                                } else if ($scope.options.hours === 12 && newMinutesValue < 0) {
                                    $scope.format === 'AM' ? $scope.format = 'PM' : $scope.format = 'AM';
                                    $scope.options.hours -= 1;
                                    $scope.options.minutes = newMinutesValue + 60;
                                } else if ($scope.options.hours < 12 && newMinutesValue < 0) {
                                    $scope.options.hours -= 1;
                                    if ($scope.options.hours <= 0) {
                                        $scope.options.hours = 12;
                                    }
                                    $scope.options.minutes = newMinutesValue + 60;
                                } else if ($scope.options.hours === 12 && newMinutesValue == 0) {
									$scope.options.minutes = 0;
								}
                            } else {
                                // meridian is false, 24H format, hours between 0-23
                                if (newMinutesValue > 0) {
                                    $scope.options.minutes = newMinutesValue;
                                } else if ($scope.options.hours === 0 && newMinutesValue < 0) {
                                    $scope.options.hours = 23;
                                    $scope.options.minutes = newMinutesValue + 60;
                                } else if ($scope.options.hours > 0 && newMinutesValue <= 0) {
                                    if ($scope.options.hours === 1) {
                                        $scope.options.hours = 1;
                                        $scope.options.minutes = 0;
                                    } else {
                                        $scope.options.hours -= 1;
                                        $scope.options.minutes = newMinutesValue + 60;
                                    }
                                }
                            }
							$scope.stringHours = formattingHours($scope.options.hours);
                            $scope.stringMinutes = formattingMinutes($scope.options.minutes);
                        }
                    };
                }
                else {
                    throw 'undefined argument or mismatch variable type in Notifier Callback';
                }
            },
            amPmHandle = function () {
                if (!!$scope.options.meridian) {
                    if ($scope.options.hours > 12) {
                        $scope.options.hours -= 12;
                        $scope.format = 'PM';
                    } else if ($scope.options.hours === 12) {
                        $scope.options.hours = 12;
                        $scope.format = 'PM';
                    } else if ($scope.options.hours === 0) {
                        $scope.options.hours = 12;
                        $scope.format = 'AM';
                    } else {
                        $scope.options.hours = $scope.options.hours;
                        $scope.format = 'AM';
                        formattingHours($scope.options.hours);
                    }
                } else {
                    // if meridian is false, AM/PM button will not be there
                    $scope.options.showAmPmButton = false;
                }
                $scope.stringHours = formattingHours($scope.options.hours);
                $scope.stringMinutes = formattingMinutes($scope.options.minutes);
            };
        
        
        initialize($scope.timePickerConfig);
        amPmHandle();
        //$scope.timePickerConfig.setTime($scope.time);
        
    }]);
});
