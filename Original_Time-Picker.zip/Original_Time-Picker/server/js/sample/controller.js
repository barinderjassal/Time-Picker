/**
 * Created by Barinderjit Singh on 20/10/16.
 * Description:
 *
 */
define([
    'angular',
    'moment',
    'server/js/sample/sample'
], function (angular, moment) {
    angular.module('SampleTimePickerView')
        .controller('SampleTimePickerViewController', ['$scope', '$filter', function ($scope, $filter) {
            $scope.timePickerConfigSample = {
                'isMeridian': true,
                'hoursStep': [1,2,3],
                'minutesStep': [1,5, 10, 15, 20, 25, 30],
                'readOnlyInput': false,
                'currentDate': new Date(),
                'setHour': 9,
                'setMin': 30,
                'setTime': function (date) {
                    var d = new Date();
                    console.log(d);
                } 
            };
            
        }]);
});
